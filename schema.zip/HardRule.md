# valid key

> NOTE: The following ECMAScript types are valid keys:
>
> - `Number` primitive values, except NaN. This includes Infinity and -Infinity.
> - `Date` objects, except where the [[DateValue]] internal slot is NaN.
> - `String` primitive values.
> - `ArrayBuffer` objects (or views on buffers such as `Uint8Array`).
> - `Array` objects, where every item is defined, is itself a valid key, and does not directly or indirectly contain itself. This includes empty arrays. Arrays can contain other arrays.
>
> Attempting to convert other ECMAScript values to a [key](https://www.w3.org/TR/IndexedDB-3/#key) will fail.

